#ifndef _PYTHONQT_QTBINDINGS_H
#define _PYTHONQT_QTBINDINGS_H

#include "PythonQtSystem.h"

/// Initialize Qt bindings enabled at configuration time
PYTHONQT_EXPORT void PythonQt_init_QtBindings();

#endif

